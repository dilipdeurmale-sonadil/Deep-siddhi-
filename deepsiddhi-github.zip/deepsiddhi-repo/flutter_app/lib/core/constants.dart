import 'package:flutter/material.dart';

class AppConst {
  static const appName = 'दीपसिद्धी';
  static const appNameEn = 'DeepSiddhi';
  static const tagline = 'शिष्यवृत्ती स्मार्ट सराव';
  static const storeListing = 'DeepSiddhi – Scholarship Smart Practice';
  static const logoAsset = 'assets/icon/DeepSiddhi_Icon_512x512.png';
  static const creditLine1 = 'निर्मिती व संकल्पना:';
  static const creditLine2 = 'श्री. दिलीप के. देऊरमले';
  static const copyright = '© सर्व हक्क सुरक्षित';
  static const developerDetail =
      'सहायक शिक्षक, जि. प. प्राथमिक शाळा ईळदा, ता. अर्जुनी मोरगाव, जि. गोंदिया';
  static const grades = [4, 7];
  static const secondsPerQuestion = 30;
}

class AppColors {
  static const blue = Color(0xFF2979FF);
  static const green = Color(0xFF2ECC71);
  static const orange = Color(0xFFFF9800);
  static const purple = Color(0xFF8E44AD);
  static const yellow = Color(0xFFFFC107);
  static const red = Color(0xFFE74C3C);
  static const bg = Color(0xFFF4F8FF);
}
